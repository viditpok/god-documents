Welcome to my game, Block Run!

Gameplay:
In this game, you take control of a blue sprite box and your objective is to get to the green goal tile box. To do so, you must move your blue sprite box using the arrow keys to navigate up, down, right and left. Be careful though, there are red obstacle boxes that you must avoid or else you will have to start again.

Scoring:
As you progress through the game, your score will increase and you can keep track of it with the score counter located at the bottom left of the screen. The score counter shows how far you have made it in the game.

Controls:

Use the up arrow key to move up.
Use the down arrow key to move down.
Use the right arrow key to move right.
Use the left arrow key to move left.
Winning:
Once you successfully reach the green goal tile box, you will have completed the game! Good luck and have fun!

Note:
This game is meant to be a fun and casual experience, and is not meant to be overly challenging. Enjoy!