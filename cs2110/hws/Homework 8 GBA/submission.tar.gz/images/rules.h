/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=200x120 rules rules.png 
 * Time-stamp: Tuesday 04/04/2023, 02:46:33
 * 
 * Image Information
 * -----------------
 * rules.png 200@120
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RULES_H
#define RULES_H

extern const unsigned short rules[24000];
#define RULES_SIZE 48000
#define RULES_LENGTH 24000
#define RULES_WIDTH 200
#define RULES_HEIGHT 120

#endif

