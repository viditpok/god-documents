/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 welcome welcome.png 
 * Time-stamp: Sunday 04/02/2023, 18:39:48
 * 
 * Image Information
 * -----------------
 * welcome.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WELCOME_H
#define WELCOME_H

extern const unsigned short welcome[38400];
#define WELCOME_SIZE 76800
#define WELCOME_LENGTH 38400
#define WELCOME_WIDTH 240
#define WELCOME_HEIGHT 160

#endif

