#include "main.h"

#include <stdio.h>
#include <stdlib.h>

#include "gba.h"

#define MODE3 3

#include "images/congrats.h"
#include "images/welcome.h"
#include "images/lose.h"
#include "images/rules.h"


enum gba_state {
  START,
  RULES,
  PLAY,
  WIN,
  LOSE,
};

int main(void) {
  // Manipulate REG_DISPCNT here to set Mode 3. //
  REG_DISPCNT = MODE3 | BG2_ENABLE;

  // Save current and previous state of button input.
  u32 previousButtons = BUTTONS;
  u32 currentButtons = BUTTONS;

  // Load initial application state
  enum gba_state state = START;

  struct Sprite s;
  s.row = 20;
  s.col = 120;
  s.score = 0;

  struct Obstacle o1;
  o1.row = 20;
  o1.col = 80;

  struct Obstacle o2;
  o2.row = 50;
  o2.col = 80;

  struct Obstacle o3;
  o3.row = 80;
  o3.col = 80;

  struct Obstacle o4;
  o4.row = 110;
  o4.col = 80;
  
  struct Obstacle o5;
  o5.row = 140;
  o5.col = 80;

  struct Obstacle o6;
  o6.row = 170;
  o6.col = 80;

  struct Obstacle o7;
  o7.row = 200;
  o7.col = 80;

  struct Obstacle o8;
  o8.row = 10;
  o8.col = 50;

  struct Obstacle o9;
  o9.row = 115;
  o9.col = 50;

  struct Obstacle o10;
  o10.row = 220;
  o10.col = 50;

  struct GoalTile gt;
  gt.row = 190;
  gt.col = 25;

  int rowTemp = 0;
  while (1) {
    currentButtons = BUTTONS;

    if (KEY_JUST_PRESSED(BUTTON_SELECT, currentButtons, previousButtons)) {
      main();
    }

    

    switch (state) {
      case START:
      waitForVBlank();
      drawFullScreenImageDMA(welcome);
      int col = 150;
      if (KEY_JUST_PRESSED(BUTTON_START, currentButtons, previousButtons)) {
        waitForVBlank();
        fillScreenDMA(BLACK);
        state = RULES;
      }
      if (rowTemp > 240) {
        rowTemp = 0;
      }
      rowTemp += 1;
      drawString(rowTemp, col, "PLAY!", WHITE);
        break;

      case RULES:
      waitForVBlank();
      drawImageDMA(20, 20, 200, 120, rules);
      if (KEY_JUST_PRESSED(BUTTON_START, currentButtons, previousButtons)) {
        fillScreenDMA(BLACK);
        drawRectDMA(140, 0, 240, 20, BLACK);
        state = PLAY;
      }
        break;

      case PLAY:
      waitForVBlank();
      drawSprite(s.row, s.col);
      drawObstacle(o1.row, o1.col);
      drawObstacle(o2.row, o2.col);
      drawObstacle(o3.row, o3.col);
      drawObstacle(o4.row, o4.col);
      drawObstacle(o5.row, o5.col);
      drawObstacle(o6.row, o6.col);
      drawObstacle(o7.row, o7.col);
      drawObstacle(o8.row, o8.col);
      drawObstacle(o9.row, o9.col);
      drawObstacle(o10.row, o10.col);
      drawGoalTile(gt.row, gt.col);

      char scoreString[20];
      sprintf(scoreString, "Score: %d", s.score);

      if (KEY_DOWN(BUTTON_RIGHT, currentButtons) && (s.row + 8 != 240)) {
        unDrawSprite(s.row, s.col);
        drawSprite(s.row += 2, s.col); 
        unDrawScore(5, 145);
        s.score++;
        drawString(5, 145, scoreString, CYAN);
      }

      if (KEY_DOWN(BUTTON_LEFT, currentButtons) && (s.row != 0)) {
        unDrawSprite(s.row, s.col);
        drawSprite(s.row -= 2, s.col);
        unDrawScore(5, 145);
        s.score--;
        drawString(5, 145, scoreString, CYAN);
      }

      if (KEY_DOWN(BUTTON_UP, currentButtons) && (s.col != 0)) {
        unDrawSprite(s.row, s.col);
        drawSprite(s.row, s.col -= 2);
        unDrawScore(5, 145);
        s.score++;
        drawString(5, 145, scoreString, CYAN);
      }

      if (KEY_DOWN(BUTTON_DOWN, currentButtons) && (s.col + 8 != 140)) {
        unDrawSprite(s.row, s.col);
        drawSprite(s.row, s.col += 2);
        unDrawScore(5, 145);
        s.score--;
        drawString(5, 145, scoreString, CYAN);
      }

      if ((s.row + 8 >= o1.row) && (s.row <= o1.row + 16) && (s.col + 8 >= o1.col) && (s.col <= o1.col + 16)) {
        s.score--;
        state = LOSE;
      }

      if ((s.row + 8 >= o2.row) && (s.row <= o2.row + 16) && (s.col + 8 >= o2.col) && (s.col <= o2.col + 16)) {
        s.score--;
        state = LOSE;
      }

      if ((s.row + 8 >= o3.row) && (s.row <= o3.row + 16) && (s.col + 8 >= o3.col) && (s.col <= o3.col + 16)) {
        s.score--;
        state = LOSE;
      }

      if ((s.row + 8 >= o4.row) && (s.row <= o4.row + 16) && (s.col + 8 >= o4.col) && (s.col <= o4.col + 16)) {
        s.score--;
        state = LOSE;
      }

      if ((s.row + 8 >= o5.row) && (s.row <= o5.row + 16) && (s.col + 8 >= o5.col) && (s.col <= o5.col + 16)) {
        s.score--;
        state = LOSE;
      }

      if ((s.row + 8 >= o6.row) && (s.row <= o6.row + 16) && (s.col + 8 >= o6.col) && (s.col <= o6.col + 16)) {
        s.score--;
        state = LOSE;
      }

      if ((s.row + 8 >= o7.row) && (s.row <= o7.row + 16) && (s.col + 8 >= o7.col) && (s.col <= o7.col + 16)) {
        s.score--;
        state = LOSE;
      }

      if ((s.row + 8 >= o8.row) && (s.row <= o8.row + 16) && (s.col + 8 >= o8.col) && (s.col <= o8.col + 16)) {
        s.score--;
        state = LOSE;
      }

      if ((s.row + 8 >= o9.row) && (s.row <= o9.row + 16) && (s.col + 8 >= o9.col) && (s.col <= o9.col + 16)) {
        s.score--;
        state = LOSE;
      }

      if ((s.row + 8 >= o10.row) && (s.row <= o10.row + 16) && (s.col + 8 >= o10.col) && (s.col <= o10.col + 16)) {
        s.score--;
        state = LOSE;
      }

      if ((s.row + 8 >= gt.row) && (s.row <= gt.row + 20) && (s.col + 8 >= gt.col) && (s.col <= gt.col + 12)) {
        state = WIN;
      }

        break;
      case WIN:
      waitForVBlank();
      drawFullScreenImageDMA(congrats);
      if (KEY_JUST_PRESSED(BUTTON_START, currentButtons, previousButtons)) {
        main();
      }

        break;
      case LOSE:
      waitForVBlank();
      drawFullScreenImageDMA(lose);
      if (KEY_JUST_PRESSED(BUTTON_START, currentButtons, previousButtons)) {
        main();
      }
      
        break;
    }

    previousButtons = currentButtons; // Store the current state of the buttons
  }

  UNUSED(previousButtons); // You can remove this once previousButtons is used

  return 0;
}
